# final project group7
A simple art directory that retrieves artworks according to the chosen filters.
Made by group 7.
Gargi Nandanpawar, Jessika Makinen, Gaia Liistro, Dominique Rueda
